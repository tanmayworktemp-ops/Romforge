# RomForge AI — 100% Local Android Project (On-Device / No-PC Ready)

## Stack
- **Native Android (Kotlin + Jetpack Compose)** — `compileSdk = 36`, `targetSdk = 36`, `minSdk = 26`
- **Privileged / Root Support:** Shizuku API + `libsu` (KernelSU / Magisk / APatch)
- **Web Companion:** `web/index.html` (runs 100% locally in Chrome on your phone)

## Build Locally on Your Android Phone (No PC, No Cloud Platforms)
1. Unzip `romforge_local_android_project.zip` to your phone's internal storage (e.g., `/sdcard/RomForgeAI/`).
2. Open the `android/` folder in a local on-device Kotlin/Gradle builder (such as **PocketCode** or **AndroidIDE** on Android).
3. Tap **Build Debug APK** (runs `gradle assembleDebug`) to generate:
   `android/app/build/outputs/apk/debug/app-debug.apk`
4. Tap the generated `app-debug.apk` to install it directly on your phone.

## Local Release Signing (Optional)
1. Generate a local PKCS12 keystore:
   `keytool -genkeypair -v -storetype PKCS12 -keystore romforge-release.jks -alias romforge-key -keyalg RSA -keysize 2048 -validity 10000`
2. Copy `android/keystore.properties.example` to `android/keystore.properties` and fill in your local keystore path and passwords.
3. Keep an offline local backup of `romforge-release.jks` and your passwords (losing them blocks future app updates under `com.romforge.ai`).
4. Run `gradle assembleRelease` inside `android/` to produce:
   `android/app/build/outputs/apk/release/app-release.apk`
