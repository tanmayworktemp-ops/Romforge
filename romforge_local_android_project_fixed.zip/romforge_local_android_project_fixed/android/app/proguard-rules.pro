# Keep Shizuku & libsu classes from R8 stripping
-keep class rikka.shizuku.** { *; }
-keep class com.topjohnwu.superuser.** { *; }
