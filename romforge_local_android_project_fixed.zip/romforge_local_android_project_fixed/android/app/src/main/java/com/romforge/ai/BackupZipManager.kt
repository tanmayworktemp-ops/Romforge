package com.romforge.ai

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

enum class BackupTargetLocation(val basePath: String) {
    INTERNAL("/sdcard/RomForge/Backups/"),
    SD_CARD("/storage/sdcard1/RomForge/Backups/"),
    USB_OTG("/mnt/media_rw/usbotg/RomForge/Backups/")
}

class BackupZipManager {
    private val safeNameRegex = Regex("^[a-zA-Z0-9_-]+$")
    private val safePathRegex = Regex("^[a-zA-Z0-9/_.-]+$")

    fun buildDdCommands(partitions: List<String>, stagingDir: String): List<String> {
        require(safePathRegex.matches(stagingDir)) { "Invalid staging directory path." }
        return partitions.map { part ->
            require(safeNameRegex.matches(part)) { "Invalid partition name: $part" }
            val blockName = if (part == "existing_rom") "super" else part
            "dd if='/dev/block/by-name/$blockName' of='$stagingDir/$part.img' bs=4096"
        }
    }

    fun packageToZip(stagingDir: File, outputZip: File): String {
        outputZip.parentFile?.mkdirs()
        ZipOutputStream(FileOutputStream(outputZip)).use { zos ->
            stagingDir.listFiles()?.forEach { file ->
                if (file.isFile) {
                    zos.putNextEntry(ZipEntry(file.name))
                    FileInputStream(file).use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
        }
        return sha256(outputZip)
    }

    fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        FileInputStream(file).use { fis ->
            val buf = ByteArray(8192)
            var read = fis.read(buf)
            while (read != -1) {
                digest.update(buf, 0, read)
                read = fis.read(buf)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
