package com.romforge.ai

import com.topjohnwu.superuser.Shell
import rikka.shizuku.Shizuku

enum class PrivilegeProvider {
    KERNELSU, MAGISK, APATCH, SHIZUKU, NONE
}

data class DeviceTelemetry(
    val model: String,
    val codename: String,
    val soc: String,
    val ramGb: Int,
    val currentRom: String,
    val isAbPartition: Boolean,
    val hasDynamicSuper: Boolean,
    val bootloaderLocked: Boolean,
    val verifiedBootState: String,
    val privilegeProvider: PrivilegeProvider
) {
    val isSafeToFlashOnDevice: Boolean
        get() = !bootloaderLocked && privilegeProvider in setOf(
            PrivilegeProvider.KERNELSU,
            PrivilegeProvider.MAGISK,
            PrivilegeProvider.APATCH
        )

    fun safetyBlockReason(): String? = when {
        bootloaderLocked && privilegeProvider != PrivilegeProvider.NONE ->
            "SAFETY BLOCK: Device is rooted (${privilegeProvider.name}) but Bootloader is LOCKED (ro.boot.flash.locked=1). Flashing unsigned recovery/ROM will fail AVB and cause a bootloop."
        bootloaderLocked ->
            "Bootloader is LOCKED. Unlock bootloader via Fastboot (PC or USB-OTG) before flashing custom recovery."
        else -> null
    }
}

class DeviceInspector {
    private val safePropKeyRegex = Regex("^[a-zA-Z0-9._-]+$")

    fun detectPrivilegeProvider(): PrivilegeProvider {
        if (Shell.getShell().isRoot) {
            val ksu = Shell.cmd("ksud -V").exec().isSuccess
            if (ksu) return PrivilegeProvider.KERNELSU
            val apatch = Shell.cmd("apd -V").exec().isSuccess
            if (apatch) return PrivilegeProvider.APATCH
            return PrivilegeProvider.MAGISK
        }
        return if (Shizuku.pingBinder()) PrivilegeProvider.SHIZUKU else PrivilegeProvider.NONE
    }

    fun inspect(): DeviceTelemetry {
        val provider = detectPrivilegeProvider()
        val codename = readProp("ro.product.device", "unknown")
        val model = readProp("ro.product.model", "Android Device")
        val soc = readProp("ro.board.platform", "arm64")
        val ab = readProp("ro.build.ab_update", "false") == "true"
        val dynamic = readProp("ro.boot.dynamic_partitions", "false") == "true"
        val locked = readProp("ro.boot.flash.locked", "1") == "1"
        val vbs = readProp("ro.boot.verifiedbootstate", "green")
        val rom = readProp("ro.build.display.id", "Stock")
        val ramMb = (Runtime.getRuntime().maxMemory() / (1024 * 1024)).toInt().coerceAtLeast(4096) / 1024
        return DeviceTelemetry(model, codename, soc, ramMb, rom, ab, dynamic, locked, vbs, provider)
    }

    private fun readProp(key: String, fallback: String): String {
        if (!safePropKeyRegex.matches(key)) return fallback
        val res = Shell.cmd("getprop '$key'").exec()
        return res.out.firstOrNull()?.trim()?.takeIf { it.isNotEmpty() } ?: fallback
    }
}
