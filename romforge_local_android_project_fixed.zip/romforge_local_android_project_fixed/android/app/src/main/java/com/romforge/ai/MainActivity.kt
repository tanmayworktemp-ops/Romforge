package com.romforge.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val inspector = DeviceInspector()
        val recommender = RomCatalogRecommender()
        val builder = OfficeAiRomBuilder()

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                var telemetry by remember { mutableStateOf<DeviceTelemetry?>(null) }
                var buildResult by remember { mutableStateOf<RomBuildResult?>(null) }

                LaunchedEffect(Unit) {
                    val detected = withContext(Dispatchers.IO) { inspector.inspect() }
                    telemetry = detected
                    buildResult = builder.runBuildPipeline(
                        detected.codename,
                        RomBuildMode.FROM_SCRATCH,
                        AiEngineMode.LOCAL_LIGHTWEIGHT_LLM,
                        "LineageOS 24 + KernelSU"
                    )
                }

                Scaffold { padding ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(padding)
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("RomForge AI — Android", style = MaterialTheme.typography.headlineSmall)
                        val activeTelemetry = telemetry
                        if (activeTelemetry == null) {
                            CircularProgressIndicator()
                            Text("Inspecting device telemetry locally...")
                        } else {
                            Text("Device: ${activeTelemetry.model} (${activeTelemetry.codename}) | ${activeTelemetry.privilegeProvider}")
                            activeTelemetry.safetyBlockReason()?.let { warning ->
                                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                                    Text(warning, modifier = Modifier.padding(12.dp))
                                }
                            }
                            Text("Recommended ROMs: ${recommender.searchAndRecommend(activeTelemetry.codename).joinToString { it.name }}")
                            Button(onClick = {
                                buildResult = builder.runBuildPipeline(
                                    activeTelemetry.codename,
                                    RomBuildMode.FROM_EXISTING_ROM,
                                    AiEngineMode.CLOUD_API_AI,
                                    "Debloat + KernelSU + MicroG"
                                )
                            }) {
                                Text("Run Office AI ROM Builder (Auto-Selected)")
                            }
                            buildResult?.let { result ->
                                Text("Office AI Stages: ${result.stages.size} departments completed (${result.engine})")
                            }
                        }
                    }
                }
            }
        }
    }
}
