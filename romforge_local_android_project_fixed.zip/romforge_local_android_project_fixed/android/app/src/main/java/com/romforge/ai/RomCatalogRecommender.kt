package com.romforge.ai

data class RomListing(
    val name: String,
    val codenames: List<String>,
    val official: Boolean,
    val maintainer: String,
    val hasGapps: Boolean,
    val passesPlayIntegrity: Boolean,
    val stabilityScore: Double,
    val batteryScore: Double,
    val knownBugs: String,
    val url: String
)

class RomCatalogRecommender {
    private val catalog = listOf(
        RomListing("LineageOS 24", listOf("alioth", "sweet", "panther"), true, "LineageOS Team", false, true, 9.6, 9.4, "Requires PlayIntegrityFix for strict banking apps", "https://download.lineageos.org/"),
        RomListing("PixelOS 17.0", listOf("alioth", "sweet"), true, "Tkiliay / Aryan & Zohaib", true, true, 9.4, 9.1, "Clean Pixel experience; monthly updates", "https://pixelos.net/download"),
        RomListing("crDroid v13.1", listOf("alioth", "sweet"), true, "crDroid Maintainers", false, true, 9.2, 9.3, "Vanilla build; flash NikGApps if needed", "https://crdroid.net/downloads"),
        RomListing("Evolution X", listOf("alioth", "sapphire", "marble"), true, "Evolution X Team", true, true, 8.9, 8.7, "Feature-rich Evolver tweaks", "https://github.com/evolution-x")
    )

    fun searchAndRecommend(partialQuery: String, gappsOnly: Boolean? = null, officialOnly: Boolean = false): List<RomListing> {
        val q = partialQuery.trim().lowercase()
        return catalog.filter { rom ->
            (!officialOnly || rom.official) &&
            (gappsOnly == null || rom.hasGapps == gappsOnly) &&
            (q.isEmpty() || rom.name.lowercase().contains(q) || rom.codenames.any { it.contains(q) })
        }.sortedByDescending { it.stabilityScore * 0.55 + it.batteryScore * 0.45 }
    }
}
