#!/usr/bin/env bash
# 100% Local Offline-Capable Android APK Build Script for RomForge AI
# Usage: ./build-apk.sh [debug|release]
set -euo pipefail

MODE="${1:-debug}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=== 1. Verifying Local JDK 17+ & Android SDK ==="
java -version
javac -version
if [ -z "${ANDROID_HOME:-}" ]; then
  echo "ERROR: ANDROID_HOME is not set. Export ANDROID_HOME to your local Android SDK path."
  exit 1
fi
if [ ! -d "$ANDROID_HOME/platforms/android-36" ]; then
  echo "WARNING: Android 16 (API 36) platform not found at $ANDROID_HOME/platforms/android-36"
fi

GRADLE_CMD="./gradlew"
if [ ! -x "$GRADLE_CMD" ]; then
  if command -v gradle >/dev/null 2>&1; then
    GRADLE_CMD="gradle"
  else
    echo "ERROR: Neither ./gradlew nor system 'gradle' was found."
    echo "Install Gradle 8.11.1+ locally or open android/ in Android Studio / AndroidIDE / PocketCode."
    exit 1
  fi
fi

if [ "$MODE" = "release" ]; then
  if [ ! -f "keystore.properties" ]; then
    echo "WARNING: android/keystore.properties not found. Output will be app-release-unsigned.apk."
  fi
  "$GRADLE_CMD" assembleRelease
  echo "=== Release APK Output ==="
  echo "android/app/build/outputs/apk/release/app-release.apk"
else
  "$GRADLE_CMD" assembleDebug
  echo "=== Debug APK Output ==="
  echo "android/app/build/outputs/apk/debug/app-debug.apk"
fi
